module.exports = {
	extends: ['stylelint-config-airbnb', 'stylelint-prettier/recommended'],
	plugins: ['stylelint-order', 'stylelint-scss'],
	rules: { 'prettier/prettier': true },
}
